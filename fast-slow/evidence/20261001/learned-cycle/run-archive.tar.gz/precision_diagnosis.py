"""Independent arithmetic audit of two retained refusals; no solver/training call."""

import hashlib
import json
import math
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(root, folder):
    path = root / folder / "current-call.json"
    call = json.loads(path.read_text())
    result = call["result"]
    arm = folder.split("-")[1]
    theta = result["weights"] + result["biases"]
    anchor = call["before"]["weights"] + call["before"]["biases"]
    beta = call["before"]["config"]["parameter_prior"]
    alpha = call["before"]["config"]["state_prior"]
    n = call["batch_size"]
    gradient = [beta * (x-y) for x, y in zip(theta, anchor)]
    hessian = [[beta if j == k else 0.0 for k in range(3)] for j in range(3)]
    coefficients, energy = [], .5 * beta * sum((x-y)**2 for x,y in zip(theta,anchor))
    for i in range(n):
        y = call["clamps"][str(i)]
        cue = call["inputs"][2*i]
        feature = y if arm == "cycle" else call["inputs"][2*i+1]
        row = (cue, feature, 1.0)
        p = math.tanh(math.fsum(x*w for x,w in zip(row,theta)))
        error, slope = y-p, 1-p*p
        coefficient = slope*slope + 2*error*p*slope
        coefficients.append(coefficient)
        energy += .5 * (error*error + alpha*y*y) / n
        for j in range(3):
            gradient[j] += -error*slope*row[j] / n
            for k in range(3):
                hessian[j][k] += coefficient*row[j]*row[k] / n
    residual = max(map(abs, gradient))
    assert abs(residual-result["stationarity"]) < 1e-15
    assert abs(energy-result["energy"]) < 1e-14
    assert min(coefficients) > 0
    return {"call": str(path.relative_to(root)), "call_sha256": sha(path),
            "identity": call["identity"], "reason": result["reason"],
            "original_tolerance": call["before"]["config"]["tolerance"],
            "kernel_stationarity": result["stationarity"], "independent_gradient": gradient,
            "independent_hessian": hessian, "minimum_row_hessian_coefficient": min(coefficients),
            "local_hessian_psd_lower_bound": beta,
            "independent_energy": energy, "energy_ulp": math.ulp(result["energy"]),
            "gradient_squared_over_prior": sum(x*x for x in gradient)/beta,
            "same_rejected_proposal_meets_standard_1e6": residual <= 1e-6,
            "original_proposal_remains_refused": True}


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    result = {"source_sha256": sha(Path(__file__)), "original_protocol_sha256": sha(root/"protocol.json"),
              "derivation": "For fixed teacher states y, z=(cue,self-y-or-presence,1), p=tanh(theta.z), e=y-p, d=1-p². Gradient=mean(-e*d*z)+beta*(theta-anchor). Hessian=mean((d²+2*e*p*d)*z*zᵀ)+beta*I. Positive row coefficients imply local Hessian>=beta*I.",
              "cases": [audit(root, p) for p in ("regime2-flat-seed163", "regime2-cycle-seed167")],
              "interpretation": "Residuals are independently reproduced and expected local decrease is at/below floating energy ULP, consistent with roundoff-limited line search. This does not override the original1e-10 refusals, prove a1e-6 trajectory or admit either proposal. No solver call, parameter update, or new memory outcome is performed."}
    (root/"precision-diagnosis.json").write_text(json.dumps(result, sort_keys=True, indent=2)+"\n")
